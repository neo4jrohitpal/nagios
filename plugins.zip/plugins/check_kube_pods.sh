#!/bin/bash

# Nagios plugin for checking Kubernetes pod statuses individually

# Configuration
NAMESPACE="neo4j"  # Replace with your namespace if not 'default'
KUBECONFIG="/home/nagios/.kube/config"  # Replace with your kubeconfig path

#!/bin/bash

# Nagios plugin for checking the status of every pod in a Kubernetes namespace

# Configuration
#NAMESPACE="default"    # Kubernetes namespace
#KUBECONFIG="/path/to/your/kubeconfig"  # Replace with your kubeconfig path

# Function to print usage and exit
usage() {
    echo "Usage: $0 <namespace>"
    exit 3
}

# Check if namespace is provided
if [ -n "$1" ]; then
    NAMESPACE="$1"
fi

# Retrieve pod statuses
PODS=$(kubectl --kubeconfig="$KUBECONFIG" get pods -n neo4j -o jsonpath='{.items[*].status.phase}' 2>&1)
EXIT_CODE=$?

if [ $EXIT_CODE -ne 0 ]; then
    echo "CRITICAL - Failed to execute kubectl command: $PODS"
    exit 2
fi

# Check if we got any output
if [ -z "$PODS" ]; then
    echo "UNKNOWN - No pods found in namespace $NAMESPACE"
    exit 3
fi

# Count pods by status
RUNNING=$(echo "$PODS" | grep -o 'Running' | wc -l)
PENDING=$(echo "$PODS" | grep -o 'Pending' | wc -l)
FAILED=$(echo "$PODS" | grep -o 'Failed' | wc -l)
SUCCEEDED=$(echo "$PODS" | grep -o 'Succeeded' | wc -l)

# Determine Nagios status
if [ "$PENDING" -gt 0 ] || [ "$FAILED" -gt 0 ]; then
    echo "CRITICAL - Pods status: Running=$RUNNING, Pending=$PENDING, Failed=$FAILED, Succeeded=$SUCCEEDED"
    exit 2
else
    echo "OK - All pods are running. Status: Running=$RUNNING, Pending=$PENDING, Failed=$FAILED, Succeeded=$SUCCEEDED"
    exit 0
fi

