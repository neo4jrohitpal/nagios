#!/bin/bash

# Configuration
#POD_NAME="$1"
DISK_PATH=("/data" "/neo4j")
THRESHOLD_WARN=80
THRESHOLD_CRIT=90

# Check if pod name is provided
#if [ -z "$POD_NAME" ]; then
#    echo "Usage: $0 <pod-name>"
#    exit 3
#fi

# Retrieve disk usage from the pod
OUTPUT=$(kubectl --kubeconfig="/home/nagios/.kube/config" exec -n "neo4j" "pod/gke-core-1-0" -- df -Ph "$DISK_PATH" 2>&1)
EXIT_CODE=$?

if [ $EXIT_CODE -ne 0 ]; then
    echo "CRITICAL - Failed to execute kubectl command: $OUTPUT"
    exit 2
fi

# Extract disk usage percentage
SECOND_LINE=$(echo "$OUTPUT" | awk 'NR==3')

USAGE=$(echo "$SECOND_LINE" | awk '{print $5}' | sed 's/%//')

# Check if the usage is a valid number
if ! [[ "$USAGE" =~ ^[0-9]+$ ]]; then
    echo "UNKNOWN - Could not parse disk usage from output: $OUTPUT"
    exit 3
fi

# Determine the Nagios status
if [ "$USAGE" -ge "$THRESHOLD_CRIT" ]; then
    echo "CRITICAL - Disk usage at ${USAGE}% on ${DISK_PATH}"
    exit 2
elif [ "$USAGE" -ge "$THRESHOLD_WARN" ]; then
    echo "WARNING - Disk usage at ${USAGE}% on ${DISK_PATH}"
    exit 1
else
    echo "OK - Disk usage at ${USAGE}% on ${DISK_PATH}"
    exit 0
fi

